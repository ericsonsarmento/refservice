<?php
    #avaliação do prato numero dois

    #inicia a conexão com o banco de dados
    include "conect_bd_refservice.inc";
    
    #Adiciona a zona padrão para data/hora do país.
    date_default_timezone_set('America/Belem');
    
    #Pega a data de hoje
    $dia = date('N');
    $i=1;
    
    #Faz uma consulta em busca dos registros dos pratos do dia de hoje.
    $result=mysql_query("SELECT c.cardapio_id, c.cardapio_nome FROM cardapio c, card_semana s WHERE  c.cardapio_id = s.id_prato and (s.dia_semana = '$dia') ORDER by cardapio_id");
    
    #Cria um array dos registros retornados
    $registros = mysql_num_rows($result);
    
    #Pega o id do segundo prato
    for ($y=0; $y < $registros-1; $y++){
		$col = mysql_fetch_array($result);        
		$id = $col[0];

    }
            
                        
            
            #Faz uma consulta do  prato avaliado na tabela de avaliacao.
            $result1 = mysql_query("select * from avaliacao where ava_id_prato=".$id);
            
            #Conta as linhas no banco de dados com a identificação da imagem
            $linhas2 = mysql_num_rows($result1);
            
            #Caso não hover registros sera inserido um novo ao banco de dados 
            if ($linhas2 == 0){
                mysql_query("INSERT into avaliacao values (".$id.",".$_POST[$i].",". (1) .", ".$_POST[$i].")") or die("Erro ao inserir");
				

            }
            #Caso exista um registro este será atualizado
            else{
                
                $array = mysql_query("select ava_star, ava_votos from avaliacao where ava_id_prato = $id");
                
                #Cria um array dos valores retornados pela consulta
                $registro = mysql_fetch_array($array);
                
                #Os votos serão somados em uma unidade antes de serem inseridos novamente no banco de dados
                $votos = $registro[1]+1; 
                
                #As estrelas serão somadas com a avaliação do estudante antes de serem inseridos novamente no banco de dados
                $star = $registro[0] + $_POST[$i];
                
                
                mysql_query("UPDATE avaliacao set ava_star = ".$star.", ava_votos = ".$votos." , ava_media = " . ($star / $votos) . " where ava_id_prato = ".$id);

            }
            
            #Cria um cookie que sera utilizado para evitar que o aluno vote mais de uma vez no mesmo prato
            setcookie("confirma1","1");
            echo"<script language='javascript' type='text/javascript'>alert('Obrigado por votar!');window.location.href='menu_aluno.php';</script>";

            #Finaliza a conexão com banco de dados
            mysql_close($conexao);
?>
