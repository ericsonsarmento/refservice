﻿<?php
 
   $matricula_aluno = $_POST['matricula'];
   $senha_aluno = $_POST['senha'];
   $flag = 0;

           if($matricula_aluno == "" or $senha_aluno == ""){ // Caso os campos de logar como aluno estejam vazios será enviado uma mensagem informando que existem campos vazios.
   		    
		    echo"<script language='javascript' type='text/javascript'>alert('Os campos não podem estar vazios');window.location.href='http://estagioifpa.esy.es/login_usuario.html';</script>";
			
			}
		   else{ // Caso os campos não estejam vazios sera carregado o banco de dados.
		     include "conect_bd_refservice.inc"; //Conectando banco de dados.
			 
			  $result =mysql_query("SELECT * FROM aluno where aluno_matricula = '{$matricula_aluno}' and aluno_senha = '{$senha_aluno}'") or die("Impossível executar a query"); // Busca no banco de dados os valores referentes a matricula e senha digitados.
              $Registro = mysql_fetch_array($result); // Cria um vetor com as linhas retornadas do banco de dados.
              $conf_mat_aluno = $Registro[0]; // Matricula do aluno.
			  $conf_nome_aluno = $Registro[1]; // Nome do aluno.
			  $conf_senha_aluno = $Registro[2]; // senha do aluno.
              if($conf_mat_aluno != "" && $conf_senha_aluno != ""){ // Se a busca no banco de dados retornar diferente de vazio teremos um login com sucesso.
		          
		          $flag=6; // rever variavel desnecessária.
				  
				  if($flag == 6){
	          
			         echo"<script language='javascript' type='text/javascript'>alert('Bem Vindo ao Refservice!');window.location.href='http://estagioifpa.esy.es/php/menu_aluno.php';</script>"; // Exibe uma tela de bem vindo após login feito com sucesso.
			            
                        // cria os cookies
				        setcookie("mat_alunoC","$matricula_aluno");
						setcookie("nome_allunoC","$conf_nome_aluno");
		                
                
				    }//fim if(flag==0)
			    }
				else{ // Caso o banco de dados retorne vazio retorna uma mensagem informando que a matricula ou senha estão incorretos e retorna pra tela inicial.
				     echo"<script language='javascript' type='text/javascript'>alert('Matricula e/ou senha incorreto (s)!');window.location.href='http://estagioifpa.esy.es/login_usuario.html';</script>";
				     return 0;
				}
			}
			   
 
               
                            
       mysql_close($conexao); // Finaliza a conexão com banco dedados.
			
			
         
?>		
		 
