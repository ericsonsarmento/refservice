<?php

        #inicia conexão com banco de dados
        include "conect_bd_refservice.inc";
        
	//Novo_prato.php
	
		$nome = $_FILES["imagem"]["name"];
		$nome_prato = $_POST['nome_prato'];
		$descricao = $_POST['descricao'];
		$tipo_refeicao = $_POST['select'];
		
                
                #formata o nome das imagem para um modelo padrão sem acentos, letras com capslook ou espaços.
		$nome = str_replace(" ","_",$nome);
		$nome = str_replace("ã","a",$nome);
		$nome = str_replace("à","a",$nome);
		$nome = str_replace("á","a",$nome);
		$nome = str_replace("â","a",$nome);
		$nome = str_replace("é","e",$nome);
		$nome = str_replace("ê","e",$nome);
		$nome = str_replace("è","e",$nome);
		$nome = str_replace("ó","o",$nome);
		$nome = str_replace("ò","o",$nome);
		$nome = str_replace("ô","o",$nome);
		$nome = str_replace("õ","o",$nome);
		$nome = str_replace("í","i",$nome);
		$nome = str_replace("ì","i",$nome);
		$nome = str_replace("ú","u",$nome);
		$nome = str_replace("ù","u",$nome);
		$nome = str_replace("û","u",$nome);
		$nome = str_replace("ü","u",$nome);
		$nome = str_replace("ç","c",$nome);

		$nome = str_replace("Ã","a",$nome);
		$nome = str_replace("À","a",$nome);
		$nome = str_replace("Á","a",$nome);
		$nome = str_replace("Â","a",$nome);
		$nome = str_replace("É","e",$nome);
		$nome = str_replace("Ê","e",$nome);
		$nome = str_replace("È","e",$nome);
		$nome = str_replace("Ó","o",$nome);
		$nome = str_replace("Ò","o",$nome);
		$nome = str_replace("Ô","o",$nome);
		$nome = str_replace("Õ","o",$nome);
		$nome = str_replace("Í","i",$nome);
		$nome = str_replace("Ì","i",$nome);
		$nome = str_replace("Ú","u",$nome);
		$nome = str_replace("Ù","u",$nome);
		$nome = str_replace("Û","u",$nome);
		$nome = str_replace("Ü","u",$nome);
		$nome = str_replace("Ç","c",$nome);
		
                
		$nome = strtolower($nome);
                
                #Quebra em um array o nome da imagem separando do formato que será validado mais a frente
		$teste = explode(".",$nome);
         
                #testa se a extensão do arquivo realmente é uma imagem
		if(($teste[1] != "gif") and ($teste[1] != "jpeg") and ($teste[1] != "png") and ($teste[1] != "jpg")){
			echo "<script type='text/javascript'>alert('Formato inválido! - $nome');window.location.href='gerenciar_cardapio.php';</script>";
		}
                #caso seja realmente uma imagem
                else{
                    
                    #será feito uma consulta para ver se ja existe uma imagem com o mesmo nome
                    if (file_exists("../cardapio/$nome")){
				$a = 1;
				#Caso exista uma imagem com mesmo nome sera adicionado no começo da mesma um numero para diferencia-las
                                while(file_exists("../cardapio/[$a]$nome")){
					$a++;
				}
				$nome = "[".$a."]".$nome;
			}
                        #Será feito uma tentativa de fazer upload da imagem caso seja possivel será feito uma inserção na tabela de cardapio
			if (move_uploaded_file($_FILES["imagem"]["tmp_name"], "../cardapio/".$nome)){	
				
				$pesquisa = mysql_query("select * from cardapio");
				$linhas = mysql_num_rows($pesquisa);
$id = $linhas + 1;
#insersão na tabela de cardapio com as inormações sobre a imagem
mysql_query("INSERT into cardapio values ('{$id}', '{$nome_prato}', '{$descricao}', '{$nome}', '{$tipo_refeicao}')") or die ("Impossivel inserir os valores!");
		




					echo "<script type='text/javascript'>alert('Novo prato adicionado com sucesso!');window.location.href='gerenciar_cardapio.php';</script>";
			}
                        #Caso não seja possivel fazer o upload será informado ao administrador que ocorreu um erro e o registro tambem não será inserido na tabela.
                        else{
				echo "<script type='text/javascript'>alert('Ocorreu um erro, por favor tente novamente!');window.location.href='gerenciar_cardapio.php';</script>";
				unlink("../cardapio/$nome");
			}
		}
                #Finaliza a conexão com o banco de dados
		mysql_close($conexao);

