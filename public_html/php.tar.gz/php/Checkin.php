<?php 
# Faz o checkin do aluno para as refeições da semana

#Inicia a conexão com banco de dados
include "conect_bd_refservice.inc";
 
 $conf_mat_aluno = "";
 #Verifica se o cookie da matricula do aluno não está vazio.
 if(IsSet($_COOKIE['mat_alunoC']))
	{
                #Pega o valor da matricula do aluno
		$conf_mat_aluno = $_COOKIE['mat_alunoC'];
	}

 #Cria um array onde serão guardados os respectivos horarios que o aluno vai comparecer ao refeitorio.
 $var = array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);

 # Pega os campos preenchidos pelo aluno e joga dentro do array para adicionar ao banco de dados
if(IsSet($_POST['checkbox-h-2a']))
{
   $var[0] = 1;
   
}

if(IsSet($_POST['checkbox-h-2b']))
{
   $var[1] = 1;
   
}

if(IsSet($_POST['checkbox-h-2c']))
{
   $var[2] = 1;
   
}

if(IsSet($_POST['checkbox-h-2d']))
{
   $var[3] = 1;
   
}

if(IsSet($_POST['checkbox-h-2e']))
{
   $var[4] = 1;
   
}

if(IsSet($_POST['checkbox-h-2f']))
{
   $var[5] = 1;
   
}

if(IsSet($_POST['checkbox-h-2g']))
{
   $var[6] = 1;
   
}

if(IsSet($_POST['checkbox-h-2h']))
{
   $var[7] = 1;
   
}

if(IsSet($_POST['checkbox-h-2i']))
{
   $var[8] = 1;
   
}

if(IsSet($_POST['checkbox-h-2j']))
{
   $var[9] = 1;
   
}

if(IsSet($_POST['checkbox-h-2k']))
{
   $var[10] = 1;
   
}

if(IsSet($_POST['checkbox-h-2l']))
{
   $var[11] = 1;
   
}

if(IsSet($_POST['checkbox-h-2m']))
{
   $var[12] = 1;
   
}

if(IsSet($_POST['checkbox-h-2n']))
{
   $var[13] = 1;
   
}

if(IsSet($_POST['checkbox-h-2o']))
{
   $var[14] = 1;
   
}

if(IsSet($_POST['checkbox-h-2p']))
{
   $var[15] = 1;
   
}

if(IsSet($_POST['checkbox-h-2q']))
{
   $var[16] = 1;
}
if(IsSet($_POST['checkbox-h-2r']))
{
   $var[17] = 1;
   
}
//===========================================================================================	
	
	
	#Consulta o banco de dados a procura de algum checkin feito pelo aluno
	$sql=mysql_query("SELECT * FROM checkins where aluno_matricula like '$conf_mat_aluno'");
        #Conta o numero de linhas retornadas na ultima consulta
	$linhas=mysql_num_rows($sql);
	
        #Testa se a matricula que foi pega do cookie existe.
	if($conf_mat_aluno > 0){
                #Testa se existe um retorno das linhas no banco de dados com a matricula do aluno.
		if($linhas=='0'){
                
                
		$exec="INSERT INTO checkins VALUES ('$conf_mat_aluno', '$var[0]','$var[1]','$var[2]','$var[3]','$var[4]','$var[5]','$var[6]','$var[7]','$var[8]','$var[9]','$var[10]','$var[11]','$var[12]','$var[13]','$var[14]','$var[15]','$var[16]','$var[17]')";
                #Insere os dados preenchidos pelo aluno no banco de dados
		mysql_query($exec);
	
		echo "<script language='javascript' type='text/javascript'>alert('Seu Check-in foi efetuado com sucesso');window.location.href='http://estagioifpa.esy.es/php/menu_aluno.php';</script>";
		}
	
                #Caso ja exista um registro com essa matricula o registro será atualizado.
		else{
		$exec="UPDATE checkins SET segcaf = '$var[0]', segalm = '$var[1]', segjnt ='$var[2]', tercaf = '$var[3]', teralm = '$var[4]', terjnt = '$var[5]', quacaf = '$var[6]' , quaaml = '$var[7]', quajnt ='$var[8]', quicaf = '$var[9]', quialm = '$var[10]', quijnt = '$var[11]', sexcaf = '$var[12]', sexalm = '$var[13]', sexjnt = '$var[14]', sabcaf = '$var[15]', sabalm = '$var[16]', sabjnt = '$var[17]' WHERE aluno_matricula = '$conf_mat_aluno'";
	
                #Atualiza o registro.
		mysql_query($exec) or die("<script language='javascript' type='text/javascript'>alert('Impossivel cadastrar os dados.');window.location.href='http://estagioifpa.esy.es/php/menu_aluno.php';</script>");

		
		echo "<script language='javascript' type='text/javascript'>alert('Seu Check-in foi atualizado com sucesso');window.location.href='http://estagioifpa.esy.es/php/menu_aluno.php';</script>";
		}
	}
	else{
            echo "<script language='javascript' type='text/javascript'>alert('Faça login para utilizar o Check-in');window.location.href='http://estagioifpa.esy.es/login_usuario.html';</script>";
	}
        #Finaliza a conexão com banco de dados
        mysql_close($conexao);
	//
?>
