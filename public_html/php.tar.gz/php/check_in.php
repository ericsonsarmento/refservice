<?php
include_once 'valida_aluno.php';
?>
<html>
    <head>
        <title>RefService - Check-In</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href='../css/bootstrap.min.css' rel='stylesheet' type='text/css'/>
        <link href='../css/estilo.css' rel='stylesheet' type='text/css'/>
    </head>
    <body>

        <!--                    NavBar                      -->
        <nav class='navbar navbar-inverse navbar-fixed-top' role='navigation' style='background: #006400;'>
            <div class='container-fluid'>
                <div class='navbar-header'>                    
                    <button type='button' class='navbar-toggle' data-toggle='collapse' data-target='#elementoCollapse1'>
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                    </button>

                    <a href='index.html' class='navbar-brand' style='margin-left: 3px;'>
                        <img src='../img/logoifpa2.png' alt='' title='Home' style='width: 145px; margin-top:-13px;'>
                    </a> 


                </div>
                <div class='collapse navbar-collapse' id='elementoCollapse1'>
                    <ul class='nav navbar-nav'>
                        <li><a href='menu_aluno.php'>Menu</a></li>
                        <li><a href='pratos_semana.php'>Pratos da Semana</a></li>
                        <li class='active'><a href='check_in.php'>Check-In</a></li> 
                        <li>
                            
                            <img class='img-circle' src='../img/bt_usuario.jpg' style='width: 30px; height: 30px; margin-top: 10px; margin-left: 15px;' alt=''/>
                            <?php $nome = $_COOKIE['nome_allunoC']; ?>
                            <b style='color: white; margin-left: 10px;'><?php echo $nome ?></b>
                            <b> <a style='color: white; margin-top: 15px; margin-left: 90px;' href='logout_aluno.php'>Logout</a>
                            </b>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <br>
        <br>

        <div class="container" style="margin-top: 50px;">
            <div class="row">

                <div class="panel">
                    <h2 style="padding-left: 20px; padding-bottom: 10px;">Check-In da Semana</h2>
                </div>

                <form action="Checkin.php" method="POST">

                    <div class="col-xs-12 col-md-2 thumbnail">
                        <div class="panel">
                            <h3 style="color: white; padding-bottom: 5px; text-align: center;"> Segunda</h3>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal" data-theme="">														
                                    <input type="checkbox" name="checkbox-h-2a" id="checkbox-h-2a">
                                    <label for="checkbox-h-2a">Café</label>
                                </fieldset>
                            </center>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2b" id="checkbox-h-2b">
                                    <label for="checkbox-h-2b">Almoço</label>
                                </fieldset>
                            </center>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2c" id="checkbox-h-2c">
                                    <label for="checkbox-h-2c">Jantar</label>
                                </fieldset>
                            </center>
                        </div>
                    </div>

                    <div class="col-xs-12 col-md-2 thumbnail">
                        <div class="panel">
                            <h3 style="color: white; padding-bottom: 5px; text-align: center;">Terça</h3>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2d" id="checkbox-h-2d">
                                    <label for="checkbox-h-2d">Café</label>
                                </fieldset>
                            </center>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2e" id="checkbox-h-2e">
                                    <label for="checkbox-h-2e">Almoço</label>
                                </fieldset>
                            </center>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2f" id="checkbox-h-2f">
                                    <label for="checkbox-h-2f">Jantar</label>
                                </fieldset>
                            </center>
                        </div>
                    </div>

                    <div class="col-xs-12 col-md-2 thumbnail">
                        <div class="panel">
                            <h3 style="color: white; padding-bottom: 5px; text-align: center;">Quarta</h3>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2g" id="checkbox-h-2g">
                                    <label for="checkbox-h-2g">Café</label>
                                </fieldset>
                            </center>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2h" id="checkbox-h-2h">
                                    <label for="checkbox-h-2h">Almoço</label>
                                </fieldset>
                            </center>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2i" id="checkbox-h-2i">
                                    <label for="checkbox-h-2i">Jantar</label>
                                </fieldset>
                            </center>
                        </div>
                    </div>


                    <div class="col-xs-12 col-md-2 thumbnail">
                        <div class="panel">
                            <h3 style="color: white;padding-bottom: 5px; text-align: center;">Quinta</h3>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2j" id="checkbox-h-2j">
                                    <label for="checkbox-h-2j">Café</label>
                                </fieldset>
                            </center>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2k" id="checkbox-h-2k">
                                    <label for="checkbox-h-2k">Almoço</label>
                                </fieldset>
                            </center>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2l" id="checkbox-h-2l">
                                    <label for="checkbox-h-2l">Jantar</label>
                                </fieldset>
                            </center>
                        </div>
                    </div>


                    <div class="col-xs-12 col-md-2 thumbnail">
                        <div class="panel">
                            <h3 style="color: white; padding-bottom: 5px; text-align: center;">Sexta</h3>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2m" id="checkbox-h-2m">
                                    <label for="checkbox-h-2m">Café</label>
                                </fieldset>
                            </center>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2n" id="checkbox-h-2n">
                                    <label for="checkbox-h-2n">Almoço</label>
                                </fieldset>
                            </center>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2o" id="checkbox-h-2o">
                                    <label for="checkbox-h-2o">Jantar</label>
                                </fieldset>
                            </center>   
                        </div>
                    </div>

                    <div class="col-xs-12 col-md-2 thumbnail">
                        <div class="panel">
                            <h3 style="color: white; padding-bottom: 5px; text-align: center;">Sabado</h3>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2p" id="checkbox-h-2p">
                                    <label for="checkbox-h-2p">Café</label>
                                </fieldset>
                            </center>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2q" id="checkbox-h-2q">
                                    <label for="checkbox-h-2q">Almoço</label>
                                </fieldset>
                            </center>
                        </div>
                        <div>
                            <center>
                                <fieldset data-role="controlgroup" data-type="horizontal">														
                                    <input type="checkbox" name="checkbox-h-2r" id="checkbox-h-2r">
                                    <label for="checkbox-h-2r">Jantar</label>
                                </fieldset>
                            </center>
                        </div>
                    </div>



                    <div class="col-xs-offset-8 col-xs-4 col-md-offset-6 col-md-6" style="margin-top: 15px;">
                        <button id="singlebutton" name="singlebutton" class="btn btn-success">Salvar</button>
                    </div>
                </form>			
            </div>
        </div>



        <footer class="espaco6">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5 col-xs-12">
                        Instituto Federal do Pará<br/>
                        Site: www.castanhal.ifpa.edu.br
                    </div>

                    <div class="col-sm-offset-2 col-sm-5 col-xs-12 rodape">

                        <small>Desenvolvido por:</small><br/>
                        <strong>Estágiarios IFPA</strong>
                    </div>
                </div>
            </div>
        </footer>


        <script src='../js/jquery-3.1.0.min.js' type='text/javascript'></script>
        <script src='../js/bootstrap.min.js' type='text/javascript'></script>
        <script src='../js/javascript.js' type='text/javascript'></script>
    </body>
</html>
