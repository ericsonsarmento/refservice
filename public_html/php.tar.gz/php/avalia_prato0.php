<?php
    #avaliação do prato numero um

    #inicia a conexão com o banco de dados
    include "conect_bd_refservice.inc";
    
    #Adiciona a zona padrão para data/hora do país.
    date_default_timezone_set('America/Belem');
    
    #Pega a data de hoje
    $dia = date('N');
    
    
    $i =0;
    
    #Faz uma consulta em busca dos registros dos pratos do dia de hoje.
    $result=mysql_query("SELECT c.cardapio_id FROM cardapio c, card_semana s WHERE  (c.cardapio_id = s.id_prato) and (s.dia_semana = '$dia') ORDER by cardapio_id");
    
    #Cria um array dos registros retornados
    $registros = mysql_fetch_array($result);
    
            
            $id = $registros[0];
            
            #Faz uma consulta do  prato avaliado na tabela de avaliacao.
            $array = mysql_query("select ava_star, ava_votos from avaliacao where ava_id_prato = $id") or die("Erro na consulta!");
            
            #Transforma em um array os registros pesquisados.
            $registro = mysql_fetch_array($array); 
            
            #Os valores que estão no banco são passados para variavel
            $votos = $registro[1];
            
            #e são somados aos novos votos dos alunos
            $novo_voto = $votos + 1;
            
            #Os valores que estão no banco são passados para variavel
            $star = $registro[0];
            
            #e são somados às novas estrelas dos alunos
            $nova_star = $star + $_POST[$i];            
            
            
            $result1 = mysql_query("select * from avaliacao where ava_id_prato=".$id);
            
            #Conta as linhas no banco de dados com a identificação da imagem
            $linhas2 = mysql_num_rows($result1);
            
            #Se o retorno é vazio sera feito uma inserção no banco.
            if ($linhas2 == 0){
                mysql_query("INSERT into avaliacao values (".$id.",".$nova_star.", ". (1) .", ".$nova_star.")") or die("Erro ao inserir - $id - $star");
                
                
            }
            
            #Se ja hover registro ele será atualizado.
            else{
                mysql_query("UPDATE avaliacao set ava_star = ".$nova_star.", ava_votos = ".$novo_voto.", ava_media = " . ($nova_star / $novo_voto) . " where ava_id_prato = ".$id);
                
                
                
            }
            #Cria um cookie que sera utilizado para evitar que o aluno vote mais de uma vez no mesmo prato
            setcookie("confirma0","1");
	    echo"<script language='javascript' type='text/javascript'>alert('Obrigado por votar!');window.location.href='menu_aluno.php';</script>";
            
            #Finaliza a conexão com banco de dados
            mysql_close($conexao);
?>
