<?php
include_once 'valida_func.php';
?>

<html>
    <head>
        <title>RefService - Consultar Avaliação</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href='../css/bootstrap.min.css' rel='stylesheet' type='text/css'/>
        <link href='../css/estilo.css' rel='stylesheet' type='text/css'/>
    </head>
    <body>

        <!--                    NavBar                      -->
<?php echo"
       <nav class='navbar navbar-inverse navbar-fixed-top' role='navigation' style='background: #006400;'>
            <div class='container-fluid'>
                <div class='navbar-header'>                    
                    <button type='button' class='navbar-toggle' data-toggle='collapse' data-target='#elementoCollapse1'>
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                    </button>

                    <img src='../img/logoifpa2.png' alt='' title='Home' style='width: 145px; margin-top:1.5px; margin-left: 3px;'>            
                </div>
                <div class='collapse navbar-collapse' id='elementoCollapse1'>
                    <ul class='nav navbar-nav'>
                        <li><a href='menu_funcionario.php'>Menu</a></li>
                        <li><a href='gerenciar_cardapio.php'>Gerenciar Cardápio</a></li>
                        <li><a href='consultar_check.php'>Consultar Check-in</a></li> 
                        <li class='active'><a href='ranking_aval.php'>Consultar Avaliação</a></li>
                        <img class='img-circle' src='../img/bt_usuario.jpg' style='width: 30px; height: 30px; margin-top: 10px; margin-left: 15px;' alt=''/>";
                        $nome = $_COOKIE['conf_nome_funcionario'];
                       echo"  <b style='color: white; margin-left: 10px;'>$nome</b> 
                    <b> <a style='color: white; margin-top: 15px; margin-left: 90px;' href='logout_funcionario.php'>Logout</a>
                    </b>
                    </li>
                    </ul>
                </div>
            </div>
        </nav>

        <br>
        <br>"
?>
        <div class="container" style="margin-top: 50px;">
            <div class="row">

                <div class="col-xs-12 col-md-offset-3 col-md-6 thumbnail">
                    <div class="panel">
                        <h3 style="color: white; padding-bottom: 5px; text-align: center;"> Ranking-Avaliação</h3>
                    </div>
                   <?php 
						include "conect_bd_refservice.inc"; 

							   		$consulta = mysql_query("SELECT a.ava_id_prato, a.ava_star, a.ava_votos, a.ava_media, c.cardapio_nome, c.cardapio_imagem FROM avaliacao a, cardapio c where a.ava_id_prato = c.cardapio_id order by a.ava_media desc");

									@$linhas = mysql_num_rows($consulta);
									for ($i = 0; $i < $linhas; $i++){
										$registros = mysql_fetch_array($consulta);

										$avaliacao[$i] = $registros[1];
										$votos[$i] = $registros[2];
										$nome_prato[$i] = $registros[4];
										$foto[$i] = $registros[5];
										$media[$i] = round($registros[3], 2);

									}



                   		
                        for ($i = 0; $i < $linhas; $i++){
                            echo "<div class='col-xs-12 col-md-12 thumbnail'> ";
                            echo "
                                
                                <div class='col-xs-1 col-md-1 thumbnail' style='background-color: gray; color: white; width: 20px; height: 30px; margin-top: 25px; margin-left: 10px;'>".($i+1)."</div>
                           
                                <div class='col-xs-3 col-md-4 imagemespaco'>
				<label style='margin-left: 10px;' data-inline='True'><img class='img-responsive' src='../cardapio/" .  $foto[$i] . "' width: '50px'; height: '50px';></label> </div>                      
                           
                           
                            <div class='col-xs-4 col-md-4 thumbnail' style='margin-top: 25px;
                            style='margin-left: 10px; margin-top: 20px;'> {$nome_prato[$i]}</div>
                     
                            <div class='col-xs-3 col-md-3 thumbnail' style='margin-top: 25px;
                            style='margin-left: 10px; margin-top: 20px;'> Nota: {$media[$i]}<br></div></div>";
                      
                            }
                  
                ?>
                </div>
            </div>
        </div>
               

              
<?php mysql_close($conexao);
?>

        <footer class="espaco2">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5 col-xs-12">
                        Instituto Federal do Pará<br/>
                        Site: www.castanhal.ifpa.edu.br
                    </div>

                    <div class="col-sm-offset-2 col-sm-5 col-xs-12 rodape">

                        <small>Desenvolvido por:</small><br/>
                        <strong>Estágiarios IFPA</strong>
                    </div>
                </div>
            </div>
        </footer>
        
        <script src='../js/jquery-3.1.0.min.js' type='text/javascript'></script>
        <script src='../js/bootstrap.min.js' type='text/javascript'></script>
        <script src='../js/javascript.js' type='text/javascript'></script> 
    </body>
</html>
