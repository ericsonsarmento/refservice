﻿<?php

include_once 'valida_aluno.php';

echo "<html>
    <head>
        <title>RefService - Login Usuário</title>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <link href='../css/bootstrap.min.css' rel='stylesheet' type='text/css'/>
        <link href='../css/estilo.css' rel='stylesheet' type='text/css'/>

    </head>
    <body>

        <!--                    NavBar                      -->

        <nav class='navbar navbar-inverse navbar-fixed-top' role='navigation' style='background: #006400;'>
            <div class='container-fluid'>
                <div class='navbar-header'>                    
                    <button type='button' class='navbar-toggle' data-toggle='collapse' data-target='#elementoCollapse1'>
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                    </button>
                        <img src='../img/logoifpa2.png' alt='' title='Home' style='width: 145px; margin-top:1.5px; margin-left: 3px;'>
                    
                    
                </div>
                <div class='collapse navbar-collapse' id='elementoCollapse1'>
                    <ul class='nav navbar-nav'>
                        <li class='active'><a href='menu_aluno.php'>Menu</a></li>
                        <li><a href='pratos_semana.php' >Pratos da Semana</a></li>
                        <li><a href='check_in.php'>Check-In</a></li> 
                        <li>
                        <img class='img-circle' src='../img/bt_usuario.jpg' style='width: 30px; height: 30px; margin-top: 10px; margin-left: 15px;' alt=''/>";
                        $nome = $_COOKIE['nome_allunoC'];
                       echo"  <b style='color: white; margin-left: 10px;'>$nome</b> 
                    <b> <a style='color: white; margin-top: 15px; margin-left: 90px;' href='logout_aluno.php'>Logout</a>
                    </b>
                    </li>
                    </ul>
                </div>
            </div>
        </nav>

        <br>
        <br>";

//Conexao com banco e pegar data do sistema
include "conect_bd_refservice.inc";
date_default_timezone_set('America/Belem');
$dia = date('N');

//Pegar o nome do dia da semana
switch ($dia){
case 1:
    $hoje = "Segunda-Feira";
    $amanha = "Terça-Feira";
break;
case 2: 
    $hoje = "Terça-Feira";
    $amanha = "Quarta-Feira";
break;
case 3:
    $hoje = "Quarta-Feira";
    $amanha = "Quinta-Feira";
break;
case 4:
    $hoje = "Quinta-Feira";
    $amanha = "Sexta-Feira";
break;
case 5:
    $hoje = "Sexta-Feira";
    $amanha = "Sabado";
break;
case 6:
    $hoje = "Sábado";
    $amanha = "Domingo";
break;
case 7:
    $hoje = "Domingo";
    $amanha = "Segunda-Feira";
break;
}

//Resultado do banco sobre as refeiçoes do dia
	
		         
                         $result=mysql_query("SELECT c.cardapio_desc, c.cardapio_imagem, s.card_refeicao, c.cardapio_nome FROM cardapio c, card_semana s WHERE  c.cardapio_id = s.id_prato and (s.dia_semana = '$dia') ORDER by cardapio_id");                  
                         
                         #conta as linhas da consulta
                         $linhas = mysql_num_rows($result);
                 
		         echo "<div class='container'>
                                    <div class='row'>
                                        <div class='col-xs-12 col-md-6'>";
                                 
				echo" <div class='panel'>
					<center><h2 style='padding-left: 20px; padding-bottom: 10px;'>Refeições de hoje ($hoje)</h2></center>
				</div>
				<div id='carousel01' class='carousel slide' data-ride='carousel' data-interval='3500'> 
                        <div class='carousel-inner'>
                            ";
				#Caso as linhas sejam diferentes de zero será montado um carrosel com as linhas da tabela
				if($linhas != 0){
				    for($i = 0; $i < $linhas; $i++){
						if ($i ==0){
							echo "<div class='item active'>";
                                                }else{
							echo "<div class='item'>";
						}
                                        
                                        #Cria um array com os resultados da consulta
				        $registro = mysql_fetch_array($result);
					$descricao = $registro[0];
				        $foto = $registro[1];
                                        $tipo_ref = $registro[2];
                                        $nome = $registro[3];
					
					
			            echo "<div class='container'>
						<div class='row'>
                                                    <div style='text-align: center;' class='col-md-4 col-xs-12'>
 					 <br><br>
							<center><img  class='img-responsive' src='../cardapio/{$foto}'></center>								
							<p style='color: #006400; font-size: 16px;'>{$tipo_ref}:</p>
                                                        <p style='color: #006400; font-size: 18px;'><strong> {$nome}</strong></p>								
							<p style='color: #006400; font-size: 16px;'>Acompanhamentos: </p>
                                                        <p style='color: #006400; font-size: 15px;'><strong>  {$descricao}</strong> </p>";


 if ($i==0){
    $i5 = $i+5;
    $i4 = $i+4;  
    $i3 = $i+3; 
    $i2 = $i+2;
    $i1 = $i+1;
 }
 if ($i==1){
    $i5 = 10;
    $i4 = 9;  
    $i3 = 8; 
    $i2 = 7;
    $i1 = 6;
 }
 if ($i==2){
    $i5 = 15;
    $i4 = 14;  
    $i3 = 13; 
    $i2 = 12;
    $i1 = 11;
 }
 
 #testa se o cookie esta vazio, Este cookie permite que o aluno vote apenas uma vez por prato
 if (empty($_COOKIE['confirma'.$i])){
     echo"<div class='stars'>
  <form action='avalia_prato".$i.".php' method='post'>
   <div class='form-group col-xs-9 col-xs-offset-1 col-md-8'>  
            <input class='star star-5'  id='$i5' name='$i' type='radio' value='5'></input>
            <label class='star star-5' for='$i5'></label>
            <input class='star star-5' id='$i4' name='$i' type='radio' value='4'></input>
            <label class='star star-5' for='$i4'></label>
            <input class='star star-5' id='$i3' name='$i' type='radio' value='3'></input>
            <label class='star star-5' for='$i3'></label>
            <input class='star star-5' id='$i2' name='$i' type='radio' value='2'></input>
            <label class='star star-5' for='$i2'></label>
            <input class='star star-5' id='$i1' name='$i' type='radio' value='1'></input>
            <label class='star star-5' for='$i1'></label>
            </div>
             <div class='form-group col-xs-12 col-md-3'>  
            <button class='btn btn-success'>Avaliar</button> 
            </div>
    </form>
    </div>";
}else{
	echo "<h5>Obrigado pelo seu voto!</h5>";
}
 echo "</div>
						</div>
					  </div></div>";
 

 
                                    
 
 }
				}	   
				echo" </div>
						<a class='left carousel-control' href='#carousel01' role='button' 
                           data-slide='prev'>
                            <span class='glyphicon glyphicon-chevron-left'></span>
                        </a>
                        <a class='right carousel-control' href='#carousel01' role='button' 
                           data-slide='next'>
                            <span class='glyphicon glyphicon-chevron-right'></span>
                        </a>
					  </div>
                                            </div>";

			



//Resultado das buscas das refeiçoes de amanha



$dia1 = $dia +1;


#faz uma consulta para buscar as refeições de amanhã
$result1 = mysql_query("SELECT c.cardapio_desc, c.cardapio_imagem, s.card_refeicao, c.cardapio_nome FROM cardapio c, card_semana s WHERE  c.cardapio_id = s.id_prato and (s.dia_semana = '$dia1')");

#Conta o numero de linhas retornadas
$linhas1 = mysql_num_rows($result1);

#monta um carrosel com os registros retornados
echo" <div class='col-xs-12 col-md-6 espaco_carousel'>
       <div class='panel'>
	<center><h2 style='padding-left: 20px; padding-bottom: 10px;'>Refeições de Amanhã ($amanha)</h2></center>
      </div>
	<div id='carousel02' class='carousel slide' data-ride='carousel' data-interval='3500'> 
            <div class='carousel-inner'>";
                            
    #caso as linhas sejam diferentes de zero sera utilizado os registros para montar um carrosel
    if ($linhas1 != 0) {
        for ($i = 0; $i < $linhas1; $i++) {
            if ($i == 0) {
            echo "<div class='item active'>";
            } else {
            echo "<div class='item'>";
            }
        
        #Monta um array com os resultados da consulta
        $registro1 = mysql_fetch_array($result1);
        $descricao1 = $registro1[0];
        $foto1 = $registro1[1];
        $tipo_ref1 = $registro1[2];
        $nome1 = $registro1[3];

        #Adiciona a imagem e informações sobre ela no carrosel
        echo "<div class='container'>
		 <div class='row'>
                    <div style='text-align: center;' class='col-md-4 col-xs-12'><br><br>
                        <center><img  class='img-responsive' src='../cardapio/{$foto1}'></center>								
			<p style='color: #006400; font-size: 16px;'>{$tipo_ref1}:</p>
                        <p style='color: #006400; font-size: 18px;'><strong> {$nome1}</strong> </p>								
			<p style='color: #006400; font-size: 16px;'>Acompanhamentos: </p>
                        <p style='color: #006400; font-size: 15px;'><strong> {$descricao1}</strong></p>
                    </div>
		 </div>
            </div>
        </div>";
    }
}
echo" </div>
			<a class='left carousel-control' href='#carousel02' role='button' 
                           data-slide='prev'>
                            <span class='glyphicon glyphicon-chevron-left'></span>
                        </a>
                        <a class='right carousel-control' href='#carousel02' role='button' 
                           data-slide='next'>
                            <span class='glyphicon glyphicon-chevron-right'></span>
                        </a>
 </div>
    </div>
        </div>
            </div>";

//Rodapé da Página
       echo " <footer class='espaco'>
            <div class='container'>
                <div class='row'>
                    <div class='col-sm-5 col-xs-12'>
                        Instituto Federal do Pará<br/>
                        Site: www.castanhal.ifpa.edu.br
                    </div>
                    
                    <div class='col-sm-offset-2 col-sm-5 col-xs-12 rodape'>
                        
                        <small>Desenvolvido por:</small><br/>
                        <strong>Estágiarios IFPA</strong>
                    </div>
                </div>
            </div>
        </footer>
        <script src='../js/jquery-3.1.0.min.js' type='text/javascript'></script>
        <script src='../js/bootstrap.min.js' type='text/javascript'></script>
        <script src='../js/javascript.js' type='text/javascript'></script>
    </body>
</html>";
       #finaliza a conexão com banco de dados
       mysql_close($conexao);
?>
