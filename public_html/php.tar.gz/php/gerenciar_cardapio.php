﻿<?php
include_once 'valida_func.php';
?>

<html>
    <head>
        <title>RefService - Gerenciar Cardapio</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href='../css/bootstrap.min.css' rel='stylesheet' type='text/css'/>
        <link href='../css/estilo.css' rel='stylesheet' type='text/css'/> 
    </head>
    <body>

        <!--                    NavBar                      -->

        <nav class='navbar navbar-inverse navbar-fixed-top' role='navigation' style='background: #006400;'>
            <div class='container-fluid'>
                <div class='navbar-header'>                    
                    <button type='button' class='navbar-toggle' data-toggle='collapse' data-target='#elementoCollapse1'>
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                    </button>

                    <img src="../img/logoifpa2.png" alt="" title="Home" style="width: 145px; margin-top:1.5px; margin-left: 3px;">


                </div>
                <div class='collapse navbar-collapse' id='elementoCollapse1'>
                    <ul class='nav navbar-nav'>
                        <li><a href='menu_funcionario.php'>Menu</a></li>
                        <li class="active"><a href='gerenciar_cardapio.php'>Gerenciar Cardápio</a></li>
                        <li><a href='consultar_check.php'>Consultar Check-in</a></li>
                        <li><a href='ranking_aval.php'>Consultar Avaliação</a></li> 
                        <li>
                            <img class='img-circle' src='../img/bt_usuario.jpg' style='width: 30px; height: 30px; margin-top: 10px; margin-left: 15px;' alt=''/>
                            <?php $nome = $_COOKIE['conf_nome_funcionario']; ?>
                            <b style='color: white; margin-left: 10px;'><?php echo $nome; ?></b> 
                            <b> <a style='color: white; margin-top: 15px; margin-left: 90px;' href='logout_funcionario.php'>Logout</a>
                            </b>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <br>
        <br>


        <!-- Inclusão de um novo prato no cardápio -->

        <div class="container" style="margin-top: 60px;">
            <div class="row">
                <form class="form-horizontal" method="post" action="novo_prato.php" enctype="multipart/form-data">
                    <div class="col-xs-12 col-md-6 col-md-offset-3 thumbnail">
                        <div class="panel">
                            <h3 style="color: white; padding-bottom: 5px; text-align: center;"> Novo Prato</h3>
                        </div>

                        <fieldset>       
                            <!-- Text input-->
                            <div class="form-group">  
                                <div class="col-xs-12">
                                    <div class="input-group">
                                        <input id="nome_prato" name="nome_prato" placeholder="Nome do Prato" class="form-control input-md" required="" type="text">
                                        <span class="input-group-addon">
                                            <label class="glyphicon glyphicon-cutlery" style="background:transparent;border:none"></label>
                                        </span> 
                                    </div>
                                </div>
                            </div>

                            <!-- Text input-->
                            <div class="form-group">                                    
                                <div class="col-xs-12">
                                    <div class="input-group">
                                        <input id="senha" name="descricao" placeholder="Acompanhamento" class="form-control input-md" required="" type="text">
                                        <span class="input-group-addon">
                                            <label class="glyphicon glyphicon-pencil" style="background:transparent;border:none"></label>
                                        </span> 
                                    </div>  
                                </div>
                            </div>

                            <!-- File input-->
                            <div class="form-group">                                    
                                <div class="col-xs-12 rolagem">
                                    <div class="input-group">
                                        <input name="imagem" required="" type="file" class="form-control input-md" required="">
                                        <span class="input-group-addon">
                                            <label class="glyphicon glyphicon-open" style="background:transparent;border:none"></label>
                                        </span> 
                                    </div>  
                                </div>
                            </div>

                            <!-- Botao input -->
                            <div class="form-group">
                                <div class="col-xs-offset-8 col-xs-4">
                                    <button name="singlebutton" class="btn btn-success">Salvar</button>
                                </div>
                            </div>

                        </fieldset>
                    </div>
                </form>
            </div>

            <div class='row'>
                <form action="excluir_prato.php" method="post">
                    <div class="col-xs-12 col-md-offset-2 col-md-8 thumbnail">

                        <div class="panel">
                            <h3 style="color: white; padding-bottom: 5px; text-align: center;"> Excluir Prato</h3>
                        </div>

                        <?php
                        include "conect_bd_refservice.inc";
                        $result = mysql_query("SELECT * FROM cardapio ORDER by cardapio_id") or die("Impossível executar a query");
                        $linhas = mysql_num_rows($result);


                        echo"<fieldset data-role='controlgroup' data-type='horizontal'>";
                        for ($i = 0; $i < $linhas; $i++) {
                            $registro = mysql_fetch_array($result);
                            $id_prato = $registro[0];
                            $nome = $registro[1];
                            $descricao = $registro[2];
                            $foto = $registro[3];
                            $tipo = $registro[4];


                            echo"
                                                   <div class='col-xs-12 col-md-6 thumbnail'>
						   <center><input type='checkbox' name='{$id_prato}' id='$id_prato'>
						   <label for='$id_prato' data-inline='True'><img src='../cardapio/" . $foto . "' width='100px' height='100px'></label>
                                                   <p style='color: #006400; font-size: 16px;'><strong style='font-size: 18px;'> $nome </strong></br> Acompanhamentos: </p>
                                                   <p style='color: #006400; font-size: 14px;'><strong> $descricao</strong> </p></center>
						 </div>
						 ";
                        }
                        echo"</fieldset>";
                        ?>

                        <div class="form-group">
                            <div class="col-xs-12">
                                <button name="singlebutton" class="btn btn-success btn-block">Excluir</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <!--                            Adicionar prato da semana                           -->
            <div class='row'>
                <div class="col-xs-12 col-md-8 col-md-offset-2 thumbnail">
                    <div class="panel">
                        <h3 style="color: white; padding-bottom: 5px; text-align: center;"> Cadastrar Cardapio</h3>
                    </div>

                    <?php
                    include "conect_bd_refservice.inc";
                    $result = mysql_query("SELECT * FROM cardapio ORDER by cardapio_id") or die("Impossível executar a query");
                    $linhas = mysql_num_rows($result);

                    for ($i = 0; $i < $linhas; $i++) {
                        $registro = mysql_fetch_array($result);
                        $id_prato = $registro[0];
                        $nome = $registro[1];
                        $descricao = $registro[2];
                        $foto = $registro[3];
                        $tipo = $registro[4];


                        echo "<center>
                                                   <div class='col-xs-6 col-md-3 thumbnail'>
						   <label data-inline='True'><img src='../cardapio/" . $foto . "' width='100px' height='100px'></label>
                                                   <p style='color: #006400; font-size: 14px;'>Código Prato: $id_prato</p>
                                                   <p style='color: #006400; font-size: 14px;'>Prato: $nome</p>
						 </div>
				 </center>		 
                        ";
                    }
                    ?>

                    <div class='col-xs-12 col-md-8 col-md-offset-2'>
                        <form method="post" action="cadastro_cardapio.php">    
                            <center>
					<div class='panel'>
                                <h4 style="color: white; padding-bottom: 5px; text-align: center;"> Adicionar no Cardápio da Semana</h4>
					</div>
                            </center>
                            <fieldset>

                                <!-- Text input-->
                                <div class="form-group">  
                                    <div class="col-xs-12">
                                        <div class="input-group">
                                            <input id="nome_prato" name="nome_prato" placeholder="Código do Prato" class="form-control input-md" required="" type="text">
                                            <span class="input-group-addon">
                                                <label class="glyphicon glyphicon-pencil" style="background:transparent;border:none"></label>
                                            </span> 
                                        </div>
                                    </div>
                                </div>

                                <!-- Select -->
                                <div class="form-group">   
                                    <div class="col-xs-3">
                                        <label>Dia:</label>
                                    </div>
                                    <div class="col-xs-9">
                                        <div class="input-group-md">
                                            <select class="form-control" name="select">
                                                <option value="1">Segunda-Feira</option>
                                                <option value="2">Terça-Feira</option>
                                                <option value="3">Quarta-Feira</option>
                                                <option value="4">Quinta-Feira</option>
                                                <option value="5">Sexta-Feira</option>
                                                <option value="6">Sábado</option>
                                            </select>                                                     
                                        </div>
                                    </div>
                                </div>

                                <!-- Select -->
                                <div class="form-group">   
                                    <div class="col-xs-3">
                                        <label>Refeição:</label>
                                    </div>
                                    <div class="col-xs-9">
                                        <div class="input-group-md">
                                            <select class="form-control" name="select">
                                                <option value="Café da Manhã">Café da Manhã</option>
                                                <option value="Almoço">Almoço</option>
                                                <option value="Jantar">Jantar</option>                                    
                                            </select>                                                     
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-xs-12">
                                        <button name="singlebutton" class="btn btn-success btn-block">Adicionar</button>
                                    </div>
                                </div>

                            </fieldset>
                        </form>    
                    </div>
                </div>
            </div> 
        </div>   


        <footer class="espaco6">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5 col-xs-12">
                        Instituto Federal do Pará<br/>
                        Site: www.castanhal.ifpa.edu.br
                    </div>

                    <div class="col-sm-offset-2 col-sm-5 col-xs-12 rodape">

                        <small>Desenvolvido por:</small><br/>
                        <strong>Estágiarios IFPA</strong>
                    </div>
                </div>
            </div>
        </footer>

        <script src='../js/jquery-3.1.0.min.js' type='text/javascript'></script>
        <script src='../js/bootstrap.min.js' type='text/javascript'></script>
        <script src='../js/javascript.js' type='text/javascript'></script> 
    </body>
</html>
