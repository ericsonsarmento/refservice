<?php
		 
		 include "conect_bd_refservice.inc";
				 date_default_timezone_set('America/Belem');
		         $hoje = Date('l');
		          
				for ($dia = 1; $dia < 8; $dia++){
					$result=mysql_query("
										SELECT s.dia_semana, c.cardapio_desc, c.cardapio_imagem, c.card_tip_ref
										FROM cardapio c, card_semana s
										WHERE c.cardapio_id = s.id_prato dia_semana = {$dia}
										ORDER BY dia_semana") or die("Impossível executar a query1");
					$linhas = mysql_num_rows($result);
                 
		         
				echo" <div class='panel'>
					//<h3>Refeições de hoje ($hoje)</h3>
				</div>
				<div id='carousel01' class='carousel slide' data-ride='carousel' data-interval='3500'> 
                        <div class='carousel-inner'>
                            ";
				
				if($linhas != 0){
				    for($i = 0; $i < $linhas; $i++){
						if ($i ==0){
							echo "<div class='item active'>";
                        }else{
							echo "<div class='item'>";
						}
				 
				        $registro = mysql_fetch_array($result);
					    $descricao = $registro[1];
				        $foto = $registro[2];
					    $tipo_ref = $registro[3];
					
					
			            echo "<div class='container'>
									<div class='row'>
										<div class='col-md-4 col-xs-12'>	
											
											<br><br>
											<img  class='img-responsive' src='fotos_cardapio/{$foto}'>
											<p>Tipo de refeição: '{$tipo_ref}'</p>								
											<p>Descrição: '{$descricao}'</p>
										</div>
									</div>
								</div></div>";
						}
				}	   
				echo" </div>
						<a class='left carousel-control' href='#carousel01' role='button' 
                           data-slide='prev'>
                            <span class='glyphicon glyphicon-chevron-left'></span>
                        </a>
                        <a class='right carousel-control' href='#carousel01' role='button' 
                           data-slide='next'>
                            <span class='glyphicon glyphicon-chevron-right'></span>
                        </a>
</div>";
			
}                 
				

			mysql_close($conexao);
		?>
