﻿<?php
 
   $cpf_funcionario = $_POST['cpf'];
   $senha_funcionario = $_POST['senha'];
   $flag = 0;
			//testa se os campos de CPF e senha estão vazios.
           if($cpf_funcionario == "" && $senha_funcionario == ""){
   		    // Retorna mensagem informando os campos vazios
		    echo"<script language='javascript' type='text/javascript'>alert('Os campos não podem estar vazios');window.location.href='http://estagioifpa.esy.es/index.html';</script>";
			
			}
		   else{ 
			// Caso os campos não estejam vazios o banco de dados e carregado para autenticar o login.
		     include "conect_bd_refservice.inc";
			// Busca no banco a linha que apresenta o CPF e a senha digitados. 
			  $result =mysql_query("SELECT * FROM funcionario where funcionario_cpf = '{$cpf_funcionario}' and funcionario_senha = '{$senha_funcionario}'") or die("Impossível executar a query"); 
              $Registro = mysql_fetch_array($result); //Transforma o retorno do banco de dados em uma array.
              $conf_cpf_funcionario = $Registro[0]; // CPF do funcionario.
			  $conf_nome_funcionario = $Registro[1]; // Nome do funcionario.
			  $conf_senha_funcionario = $Registro[2]; // Senha do funcionario.
              if($conf_cpf_funcionario != "" && $conf_senha_funcionario != ""){ //Testa se a pesquisa no banco de dados retornou vazia.
		          
		          $flag=6; 
				  
				  if($flag == 6){
	          		// Mensagem confirmando o login com sucesso e redireciona a pagina para menu_funcionario.php.
			         echo"<script language='javascript' type='text/javascript'>alert('Bem Vindo ao Refservice!');window.location.href='menu_funcionario.php';</script>";
			            // Cria os cookies guardando o nome e CPF do funcionario.
				        setcookie("conf_cpf_funcionario","$conf_cpf_funcionario");
						setcookie("conf_nome_funcionario","$conf_nome_funcionario");
		                
                
				    }//fim if(flag==0)
			    }
				else{
					// Caso o retorno do banco de dados seja vazio é informado que o CPF ou senha estão incorretos.
				     echo"<script language='javascript' type='text/javascript'>alert('CPF e/ou senha incorreto(s)!');window.location.href='http://estagioifpa.esy.es/index.html';</script>";
				     return 0;
				}
			}
			   
 
               
                            
       mysql_close($conexao);
			
			
         
?>		
		 
