﻿<?php

#Valida o cookie do aluno
include_once 'valida_aluno.php';

echo "<html>
    <head>
        <title>RefService - Login Usuário</title>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <link href='../css/bootstrap.min.css' rel='stylesheet' type='text/css'/>
        <link href='../css/estilo.css' rel='stylesheet' type='text/css'/>

    </head>
    <body>

        <!--                    NavBar                      -->

        <nav class='navbar navbar-inverse navbar-fixed-top' role='navigation' style='background: #006400;'>
            <div class='container-fluid'>
                <div class='navbar-header'>                    
                    <button type='button' class='navbar-toggle' data-toggle='collapse' data-target='#elementoCollapse1'>
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                    </button>

                    <img src='../img/logoifpa2.png' alt='' title='Home' style='width: 145px; margin-top:1.5px; margin-left: 3px;'>
                    
                    
                </div>
                <div class='collapse navbar-collapse' id='elementoCollapse1'>
                    <ul class='nav navbar-nav'>
                        <li><a href='menu_aluno.php'>Menu</a></li>
                        <li class='active'><a href='pratos_semana.php' >Pratos da Semana</a></li>
                        <li><a href='check_in.php'>Check-In</a></li> 
                        <li>
                        <img class='img-circle' src='../img/bt_usuario.jpg' style='width: 30px; height: 30px; margin-top: 10px; margin-left: 15px;' alt=''/>";
                        $nome = $_COOKIE['nome_allunoC'];
                       echo"  <b style='color: white; margin-left: 10px;'>$nome</b> 
                    <b> <a style='color: white; margin-top: 15px; margin-left: 90px;' href='logout_aluno.php'>Logout</a>
                    </b>
                    </li>
                    </ul>
                </div>
            </div>
        </nav>

        <br>
        <br>";

//Conexao com banco e pegar data do sistema
include "conect_bd_refservice.inc";

                        #define um padrão para a data/hora do país
				 date_default_timezone_set('America/Belem');
		         
                                 #Pega a data de hoje
                                 $hoje = Date('l');
		          
				for ($dia = 1; $dia < 7; $dia++){
                                    
                                    #faz uma consulta no banco de dados sobre os registros referentes a data de hoje
					$result=mysql_query("
										SELECT s.dia_semana, c.cardapio_desc, c.cardapio_imagem, s.card_refeicao, c.cardapio_nome
										FROM cardapio c, card_semana s
                                                                                WHERE c.cardapio_id = s.id_prato and dia_semana = {$dia}
										ORDER BY dia_semana") or die("Impossível executar a query1");
					
                                        #Conta o numero de linhas da consulta                                        
                                        $linhas = mysql_num_rows($result);
                                        
                                        #transforma os numeros do dia em dias da semana
                                        if ($dia == 1){
                                            $dia_semana = "Segunda-feira";
                                        }
                                        if ($dia == 2){
                                            $dia_semana = "Terça-feira";
                                        }
                                        if ($dia == 3){
                                            $dia_semana = "Quarta-feira";
                                        }
                                        if ($dia == 4){
                                            $dia_semana = "Quinta-feira";
                                        }
                                        if ($dia == 5){
                                            $dia_semana = "Sexta-feira";
                                        }
                                        if ($dia == 6){
                                            $dia_semana = "Sábado";
                                        }
		         
                                #Começa a criar o carrosel referente ao dia da semana
				echo"<div class='container'>
                                        <div class='row'> 
                                            <div class='col-xs-12 col-md-4'>
                                                <div class='panel' style='margin-top: 20px;'>
                                                    <center><h2 style='color: white;'>$dia_semana</h2></center>
				</div>
				<div id='carousel{$dia}' class='carousel slide' data-ride='carousel' data-interval='3500'> 
                        <div class='carousel-inner'>
                            ";
				#Se as linhas da consulta forem diferentes de zero os registros serão utilizados para criar o carrosel
				if($linhas != 0){
				    for($i = 0; $i < $linhas; $i++){
						if ($i ==0){
							echo "<div class='item active'>";
                        }else{
							echo "<div class='item'>";
						}
				 #Cria um array com os registros da consulta
				        $registro = mysql_fetch_array($result);
					    $descricao = $registro[1];
                                            $foto = $registro[2];
					    $tipo_ref = $registro[3];
                                            $nome = $registro[4];
					
					#Prepara a descrição do carrosel com as informações do banco de dados 
			            echo "<div class='container'>
									<div class='row'>
										<div style='text-align: center;' class='col-md-4 col-xs-12'><br><br>
                                                                                    <center><img class='img-responsive' src='../cardapio/{$foto}'></center>
                                                                                    <p style='color: #006400; font-size: 16px;'>{$tipo_ref}: </p>
                                                                                    <p style='color: #006400; font-size: 18px;'><strong>{$nome}</strong></p>
                                                                                    <p style='color: #006400; font-size: 16px;'>Acompanhamentos: </p>
                                                                                    <p style='color: #006400; font-size: 15px;'><strong>{$descricao}</strong></p>
										</div>
									</div>
								</div></div>";
						}
				}	   
				echo" </div>
						<a class='left carousel-control' href='#carousel{$dia}' role='button' 
                           data-slide='prev'>
                            <span class='glyphicon glyphicon-chevron-left'></span>
                        </a>
                        <a class='right carousel-control' href='#carousel{$dia}' role='button' 
                           data-slide='next'>
                            <span class='glyphicon glyphicon-chevron-right'></span>
                        </a>
</div>
</div>

";
			
}  
echo"</div></div>";

//Rodapé da Página
       echo " <footer style='margin-top: 40px'>
            <div class='container'>
                <div class='row'>
                    <div class='col-sm-5 col-xs-12'>
                        Instituto Federal do Pará<br/>
                        Site: www.castanhal.ifpa.edu.br
                    </div>
                    
                    <div class='col-sm-offset-2 col-sm-5 col-xs-12 rodape'>
                        
                        <small>Desenvolvido por:</small><br/>
                        <strong>Estágiarios IFPA</strong>
                    </div>
                </div>
            </div>
        </footer>
        <script src='../js/jquery-3.1.0.min.js' type='text/javascript'></script>
        <script src='../js/bootstrap.min.js' type='text/javascript'></script>
        <script src='../js/javascript.js' type='text/javascript'></script>
    </body>
</html>";
       #Finaliza a conexão com banco de dados
       mysql_close($conexao);
?>
