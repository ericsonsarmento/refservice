<?php
//Verefica se o cookie esta vazio, se estiver exibe o formulario//Formularioecho 
if(empty($_COOKIE['nome_allunoC'])){
    echo"<script language='javascript' type='text/javascript'>alert('Efetue login!');window.location.href='http://estagioifpa.esy.es/index.html';</script>";
}
?>