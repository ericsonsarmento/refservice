<?php

	$matricula_aluno = $_POST['matricula']; 
	$nome_aluno = $_POST['nome']; 
	$senha_aluno = $_POST['senha']; // senha do aluno
        $senha2 = $_POST['rep_senha']; // Autenticação da senha
	$email_aluno = $_POST['email'];
	
         # Testa se as senhas digitadas são iguais.       
        if ($senha_aluno != $senha2){
            
            // Retorna uma mensagem informando que o aluno não informou as senha iguais.		
               echo "<script language='javascript' type='text/javascript'>alert('As senhas não coincidem!');window.location.href='http://estagioifpa.esy.es/cadastro.html';</script>";
        }else{ 
          
        //Conexao com banco e pegar data do sistema
        include "conect_bd_refservice.inc";   

	// Faz uma pesquisa no banco de dados em busca da matricula do aluno.
	$result = mysql_query("select * from aluno where aluno_matricula = '{$matricula_aluno}'"); 
	$linhas = mysql_num_rows($result);
        
        
	
	// Se não for encontrado a matricula cadastrada o aluno poderá se cadastrar.
	if ($linhas == 0){
		mysql_query("INSERT into aluno values ('{$matricula_aluno}', '{$nome_aluno}', '{$senha_aluno}', '{$email_aluno}')") or die ("Impossivel inserir os valores!");
		
		echo "<script language='javascript' type='text/javascript'>alert('Cadastro realizado com sucesso, faça seu login agora mesmo!');window.location.href='http://estagioifpa.esy.es/login_usuario.html';</script>";
                
                
                
                }
	
	// Se a matricula ja existir no banco de dados o aluno não poderá fazer o cadastro.
	else{
		// Retorna uma mensagem informando que o aluno não pode cadastrar esse numero de matricula.
		
               echo "<script language='javascript' type='text/javascript'>alert('Matrícula já cadastrada!');window.location.href='http://estagioifpa.esy.es/cadastro.html';</script>";
	                
                }        
         
        }  
             
       mysql_close($conexao); // Finaliza a conexão com banco dedados. 
?>
