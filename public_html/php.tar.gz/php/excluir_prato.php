<?php 
	#Excluir prato.php

        #inicia conexão com banco de dados
	include "conect_bd_refservice.inc";

        #Realiza uma consulta na tabela cardapio.
	$result = mysql_query("SELECT * FROM cardapio order by 1") or die("Impossível executar a query");
    
        #Conta o numero de linhas retornadas.
        $linhas = mysql_num_rows($result);
	$i = 1;
        
        #Cria um laço para se repetir até que todas as linhas da consulta sejam varridas.
	while ($i <= $linhas) {

            #verifica qual imagem o administrador selecionou para apagar
		if (isset($_POST["$i"])){
                    
                    #Consulta todas as informações referentes ao id da imagem
			$exec = mysql_query("select * from cardapio where cardapio_id = $i");
                        
                        #cria um array dos valores retornados
			$registros = mysql_fetch_array($exec);
			$foto = $registros[3];
                        
                        #Seleciona o id do prato da tabela de card_semana
                        $consulta = mysql_query("select id_prato from card_semana where id_prato= '{$registros[0]}'");
			
                        
                        #Se retornar diferente de zero significa que o prato em questão foi adicionado ao cardapio da semana e não poderá ser apagado
                        if($consulta != 0){
                            echo "<script type='text/javascript'>alert('O seguinte registro não pode ser apagado pois foi adicionado ao Cardápio da Semana: {$registros[1]}');window.location.href='gerenciar_cardapio.php';</script>";
                        }
                        #Se ao tentar excluir a imagem resultar em erro o prato não sera apagado do banco de dados e retornará uma mensagem de erro.
			else if(@!unlink("../cardapio/$foto")){
				echo "<script type='text/javascript'>alert('Erro ao excluir Prato(s)');window.location.href='gerenciar_cardapio.php';</script>";
				
                        } 
                        #Caso não ocorra nenhum erro o prato selecionado será deletado e a imagem apagada
			else{
				$exec = "delete from cardapio where cardapio_imagem like '{$foto}'";
				mysql_query($exec) or die("Erro ao apagar do banco de dados!");
				$y = $i;
                                
                                #Após apagar o prato a identificação dos pratos será re-formulada a partir do prato excluido
				for ($y; $y <=$linhas; $y++){
					$valor = $y+1;
					mysql_query("UPDATE cardapio set cardapio_id = $y where cardapio_id = $valor") or die("Erro de atualização na identificação!");
				}
			}
		}

		$i++;
	}
	echo "<script type='text/javascript'>alert('Prato(s) excluídos com sucesso!');window.location.href='gerenciar_cardapio.php';</script>";
	#Finaliza conexão com banco de dados
        mysql_close($conexao);
?>
