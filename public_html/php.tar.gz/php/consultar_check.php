<?php
include_once 'valida_func.php';
?>

<html>
    <head>
        <title>RefService - Consultar Check-In</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href='../css/bootstrap.min.css' rel='stylesheet' type='text/css'/>
        <link href='../css/estilo.css' rel='stylesheet' type='text/css'/>
    </head>
    <body>

        <!--                    NavBar                      -->

        <nav class='navbar navbar-inverse navbar-fixed-top' role='navigation' style='background: #006400;'>
            <div class='container-fluid'>
                <div class='navbar-header'>                    
                    <button type='button' class='navbar-toggle' data-toggle='collapse' data-target='#elementoCollapse1'>
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                    </button>

                    <img src="../img/logoifpa2.png" alt="" title="Home" style="width: 145px; margin-top:1.5px; margin-left: 3px;">


                </div>
                <div class='collapse navbar-collapse' id='elementoCollapse1'>
                    <ul class='nav navbar-nav'>
                        <li><a href='menu_funcionario.php'>Menu</a></li>
                        <li><a href='gerenciar_cardapio.php'>Gerenciar Cardápio</a></li>
                        <li class="active"><a href='consultar_check.php'>Consultar Check-in</a></li>
                        <li><a href='ranking_aval.php'>Consultar Avaliação</a></li> 
                        <li>
                            <img class='img-circle' src='../img/bt_usuario.jpg' style='width: 30px; height: 30px; margin-top: 10px; margin-left: 15px;' alt=''/>
                            <?php
                            $nome = $_COOKIE['conf_nome_funcionario'];?>
                            <b style='color: white; margin-left: 10px;'><?php echo $nome; ?></b> 
                            <b> <a style='color: white; margin-top: 15px; margin-left: 90px;' href='logout_funcionario.php'>Logout</a>
                            </b>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <br>
        <br>

        <!-- CONEXÃO COM BANCO DE DADOS E CÓDIGOS PHP PARA PEGAR OS DADOS-->
        <?php 
		include "conect_bd_refservice.inc"; 

        $sql=mysql_query("SELECT sum(segcaf), sum(segalm), sum(segjnt), sum(tercaf), sum(teralm), sum(terjnt), sum(quacaf), sum(quaaml), sum(quajnt), sum(quicaf), sum(quialm), sum(quijnt), sum(sexcaf), sum(sexalm), sum(sexjnt), sum(sabcaf), sum(sabalm), sum(sabjnt) FROM checkins");
        $registros=mysql_fetch_array($sql);
		
		$cafseg = $registros[0];
		$almseg = $registros[1];
		$janseg = $registros[2];
		$cafter = $registros[3];
		$almter = $registros[4];
		$janter = $registros[5];
		$cafqua = $registros[6];
		$almqua = $registros[7];
		$janqua = $registros[8];
		$cafqui = $registros[9];
		$almqui = $registros[10];
		$janqui = $registros[11];
		$cafsex = $registros[12];
		$almsex = $registros[13];
		$jansex = $registros[14];
		$cafsab = $registros[15];
		$almsab = $registros[16];
		$jansab = $registros[17];

        ?>

        <div class="container" style="margin-top: 50px;">
            <div class="row">

                <div class="panel">
                    <h2 style="padding-left: 20px; padding-bottom: 10px;">Check-In Reservado da Semana</h2>
                </div>    

                <div class="col-xs-12 col-md-2 thumbnail">
                    <div class="panel">
                        <h3 style="color: white; padding-bottom: 5px; text-align: center;"> Segunda</h3>
                    </div>
                    <div>
                        <center>
                            <p>Café: <?php echo $cafseg; ?></p>
                        </center>
                    </div>
                    <div>
                        <center>
                            <p>Almoço: <?php echo $almseg; ?></p>
                        </center>
                    </div>
                    <div>
                        <center>
                            <p>Jantar: <?php echo $janseg; ?></p>
                        </center>
                    </div>
                </div>

                <div class="col-xs-12 col-md-2 thumbnail">
                    <div class="panel">
                        <h3 style="color: white; padding-bottom: 5px; text-align: center;"> Terça</h3>
                    </div>
                    <div>
                        <center>
                            <p>Café: <?php echo $cafter; ?></p>
                        </center>
                    </div>
                    <div>
                        <center>
                            <p>Almoço: <?php echo $almter; ?></p>
                        </center>
                    </div>
                    <div>
                        <center>
                            <p>Jantar: <?php echo $janter; ?></p>
                        </center>
                    </div>
                </div>


                <div class="col-xs-12 col-md-2 thumbnail">
                    <div class="panel">
                        <h3 style="color: white; padding-bottom: 5px; text-align: center;"> Quarta</h3>
                    </div>
                    <div>
                        <center>
                            <p>Café: <?php echo $cafqua; ?></p>
                        </center>
                    </div>
                    <div>
                        <center>
                            <p>Almoço: <?php echo $almqua; ?></p>
                        </center>
                    </div>
                    <div>
                        <center>
                            <p>Jantar: <?php echo $janqua; ?></p>
                        </center>
                    </div>
                </div>


                <div class="col-xs-12 col-md-2 thumbnail">
                    <div class="panel">
                        <h3 style="color: white; padding-bottom: 5px; text-align: center;"> Quinta</h3>
                    </div>
                    <div>
                        <center>
                            <p>Café: <?php echo $cafqui; ?></p>
                        </center>
                    </div>
                    <div>
                        <center>
                            <p>Almoço: <?php echo $almqui; ?></p>
                        </center>
                    </div>
                    <div>
                        <center>
                            <p>Jantar: <?php echo $janqui; ?></p>
                        </center>
                    </div>
                </div>


                <div class="col-xs-12 col-md-2 thumbnail">
                    <div class="panel">
                        <h3 style="color: white; padding-bottom: 5px; text-align: center;"> Sexta</h3>
                    </div>
                    <div>
                        <center>
                            <p>Café: <?php echo $cafsex; ?></p>
                        </center>
                    </div>
                    <div>
                        <center>
                            <p>Almoço: <?php echo $almsex; ?></p>
                        </center>
                    </div>
                    <div>
                        <center>
                            <p>Jantar: <?php echo $jansex; ?></p>
                        </center>
                    </div>
                </div>


                <div class="col-xs-12 col-md-2 thumbnail">
                    <div class="panel">
                        <h3 style="color: white; padding-bottom: 5px; text-align: center;"> Sábado</h3>
                    </div>
                    <div>
                        <center>
                            <p>Café: <?php echo $cafsab; ?></p>
                        </center>
                    </div>
                    <div>
                        <center>
                            <p>Almoço: <?php echo $almsab; ?></p>
                        </center>
                    </div>
                    <div>
                        <center>
                            <p>Jantar: <?php echo $jansab; ?></p>
                        </center>
                    </div>
                </div>

                <br> <br>		
            </div>
        </div>

<?php mysql_close($conexao);
?>

        <footer class="espaco2">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5 col-xs-12">
                        Instituto Federal do Pará<br/>
                        Site: www.castanhal.ifpa.edu.br
                    </div>

                    <div class="col-sm-offset-2 col-sm-5 col-xs-12 rodape">

                        <small>Desenvolvido por:</small><br/>
                        <strong>Estágiarios IFPA</strong>
                    </div>
                </div>
            </div>
        </footer>
    </body>
</html>
