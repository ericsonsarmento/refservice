<?php
include "conect_bd_refservice.inc";

 $excluir = "UPDATE checkins SET segcaf=0, segalm=0, segjnt=0, tercaf=0, teralm=0, terjnt=0, quacaf=0, quaaml=0, quajnt=0, quicaf=0, quialm=0, quijnt=0, sexcaf=0, sexalm=0,sexjnt=0, sabcaf=0, sabalm=0, sabjnt=0
WHERE (SELECT date_format(current_date(),'%w')) = 0"

mysql_query($excluir) or die ("<script language='javascript' type='text/javascript'>alert('Impossível excluir a lista de checkins!');window.location.href='http://estagioifpa.esy.es/php/consultar_check.php';</script>");

echo "<script language='javascript' type='text/javascript'>alert('Lista de checkins excluida!');window.location.href='http://estagioifpa.esy.es/php/consultar_check.php';</script>";
?>
