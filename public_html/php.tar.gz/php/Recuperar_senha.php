<?php
	// Recebe a matricula e o e-mail do aluno.
	$matricula_aluno = $_POST['matricula'];
	$email_aluno = $_POST['email'];

	// Inicia a conexão com banco de dados.
	include "conect_bd_refservice.inc";

	// Faz uma pesquisa no banco de dados em busca das informações referente a matricula do aluno.
	$result = mysql_query("select * from aluno where aluno_matricula = '{$matricula_aluno}' and email_aluno = '{$email_aluno}'") or die ("Impossível executar a consulta!");
	
	$linhas = mysql_num_rows($result);
	if ($linhas != 0){
		$Registro = mysql_fetch_array($result); // Cria um vetor com as linhas retornadas do banco de dados.
		$matricula = $Registro[0]; //Matricula do aluno.
		$senha = $Registro[2]; // Senha do aluno.
		$email = $Registro[3]; // E-mail do aluno.
			

		if ($email_aluno == $email){
			// Prepara as informações para enviar ao aluno.
			$headers = "MIME-Version: 1.0\n";
			$headers .= "Content-type: text/html; charset=UTF-8\n";
			$headers .= "From: estagioifpa.esy.es - Refservice<estagiarios@ifpa.com.br>"; //COLOQUE TEU EMAIL

			$subject = "Sua senha no Refservice";
			$message = "Olá, recuperamos sua senha.<br /><br />

			<strong>Senha</strong>: {$senha}<br /><br />

			Volte para o Refservice clicando <a href='http://estagioifpa.esy.es/login_usuario.html'>aqui</a>! <br /><br />

			Obrigado!<br /><br />


			Esta é uma mensagem automática, por favor não responda!";

			// Envia as informações a cima para o e-mail do aluno.
			mail($email, $subject, $message, $headers);

			echo "<script language='javascript' type='text/javascript'>alert('Um e-mail será enviado para você, Por favor consulte seu e-mail!');window.location.href='../index.html';</script>";
		}else{
			echo "<script language='javascript' type='text/javascript'>alert('Erro, matricula ou email são inválidos!');window.location.href='../esqueceu_senha.html';</script>";
		}
		
	}
	// Caso as informações de matricula e E-mail informadas pelo aluno não estejam corretas.
	else {
		// Envia uma mensagem para o aluno informando que a matricula ou E-mail não batem com as informações no banco de dados.
		echo "<script language='javascript' type='text/javascript'>alert('Matricula ou e-mail estão incorretos, por favor tente novamente!');window.location.href='../esqueceu_senha.html';</script>";
	}

	mysql_close($conexao); // Finaliza a conexão com banco dedados.
?>
