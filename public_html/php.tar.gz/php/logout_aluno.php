<?php
	//Limpa os valores dos cookies.
	setcookie("mat_alunoC");  
	setcookie("nome_allunoC");

	// Retorna a pagina inicial.
	echo"<script language='javascript' type='text/javascript'>alert('Logout Efetuado! Volte sempre!');window.location.href='http://estagioifpa.esy.es/index.html';</script>";
?>
