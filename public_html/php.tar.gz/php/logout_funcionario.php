<?php
	// Apaga os valores dos cookies ao efetuar logout.
	setcookie("conf_cpf_funcionario");
	setcookie("conf_nome_funcionario");

	echo"<script language='javascript' type='text/javascript'>alert('Logout efetuado!');window.location.href='http://estagioifpa.esy.es/index.html';</script>";
?>
