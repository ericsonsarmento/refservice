<?php 
	#Cadastra o prato da semana

        #Inicia conexão com banco de dados
	include "conect_bd_refservice.inc";

        #Recupera as informações que o administrador solicitou
	$id_prato = $_POST["id_prato"];
	$dia_semana = $_POST["select_dia"];
	$refeicao = $_POST["select_refeicao"];

        #Faz uma consulta em busca da refeição do dia da semana.
        $cont = mysql_query("select s.id_card_semana, c.cardapio_nome from cardapio c, card_semana s where (c.cardapio_id = s.id_prato) and (s.card_refeicao = '{$refeicao}') and (s.dia_semana = '{$dia_semana}')");
        
        #Conta o numero de linhas dessa ultima consulta.
        $linhas = mysql_num_rows($cont);
        
        #Cria um array dos registros retornados.
	$registro = mysql_fetch_array($cont);
        
        #Caso o retorno seja diferente de zero será feito uma atualização no registro
	if ($linhas != 0){
		
                mysql_query("UPDATE card_semana set id_prato = '{$id_prato}', dia_semana = '{$dia_semana}', card_refeicao = '{$refeicao}' where id_card_semana = ".$registro[0]) or die("Falha ao atualizar!");
		
                echo"<script language='javascript' type='text/javascript'>alert('O prato foi atualizado no cardapio da semana!');window.location.href='gerenciar_cardapio.php';</script>";
	
	}
        #caso o retorno seja zero sera feito uma inserção na tabela card_semana
        else{
                
		$consulta = mysql_query("SELECT * from card_semana");
                
                #Conta o numero de linhas no banco de dados
		$linhas = mysql_num_rows($consulta);
                
                #Cria uma variavel com o valor de linhas no banco mais um para continuar a inserção de registros desse ponto.
		$novo = $linhas + 1;

		mysql_query("INSERT into card_semana values ('{$novo}','{$id_prato}','{$dia_semana}','{$refeicao}')") or die("Erro ao inserir!");

		echo "<script language='javascript' type='text/javascript'>alert('Um novo prato foi adicionado no cardapio da semana!'); window.location.href='gerenciar_cardapio.php';</script>";
	}
        #Finaliza a conexão com banco de dados
        mysql_close($conexao);

?>
